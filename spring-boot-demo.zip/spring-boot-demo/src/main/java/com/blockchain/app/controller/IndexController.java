package com.blockchain.app.controller;

import com.blockchain.app.service.Block;
import com.blockchain.app.service.NoobChain;
import com.blockchain.app.service.SMSAPIJAVA;
import com.blockchain.app.service.smsService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.GsonBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Controller
@EnableWebMvc
public class IndexController {


    int o;  //to save OTP
    int a,b,c;
    String resultStatement;


    @RequestMapping("/")      //automatically goes to login page first
    public String login() {


        //model.put("message", NoobChain.getBlockChain().toString());
        return "login";
    }

    @RequestMapping("/login")    //here the login credentials are added
    public String home(@RequestParam("username") String username, @RequestParam("pass") String pwd, Map<String, Object> model) {

        model.put("user",username);

        if (username.equals("denin") && pwd.equals("denin")) {
            o = SMSAPIJAVA.otpCall();
            System.out.println("OTP IS " + o); // to check in log whether otp format is correct.
            return "otp";
        } else if (username.equals("george") && pwd.equals("george")) {

            return "userchoose";
        } else if (username.equals("tania") && pwd.equals("tania")) {

            return "userchoose";
        } else if (username.equals("adarsh") && pwd.equals("adarsh")) {

            return "userchoose";
        } else
            return "login";
    }
    @RequestMapping("/votepage")
    public String home( Map<String, Object> model) {
        return "vote";


    }

    @RequestMapping("/otplogin")
    public String home(@RequestParam("otp") String otp, Map<String, Object> model) {

        String conotp = Integer.toString(o);  //because equals compares with String

        if (otp.equals(conotp)) {

            return "userchoose";
        } else {
            model.put("wrongotp", "The otp you entered is wrong!");
            return "otp";
        }
    }

    @RequestMapping("/vote")
    public String submitvote(@RequestParam("vote") String voted, Map<String, Object> model) {    //saying method submitvote is never used??

        System.out.println("flag.." + voted);

        NoobChain.setBlockChain(voted);

        // model.put("message", "You selected "+voted);

        model.clear();//to clear the request parameter caches
        return "votesuccesful";
    }

    @RequestMapping("/adminlogin")
    public String admin(Map<String, Object> model) {
        //NoobChain.setBlockChain(voted);

        // model.put("message", "You selected "+voted);
        model.clear();
        return "adminlogin";
    }

    @RequestMapping("/adminresults")  //this is called by form action .THIS DOES NOT REFER TO ADMINHOME JSP PAGE

    public String adminhome(Map<String, Object> model) {




        ArrayList<Block> blockChain = NoobChain.getBlockChain();
        Map<String, Integer> dataMap = new HashMap<String, Integer>();
        if (!blockChain.isEmpty()) {

            if (!NoobChain.isChainValid(blockChain)) {    //if not valid to print the data.
                model.put("tampermsg", "Unathorized acess detected and vote data is attacked.Correct values are ");

                dataMap = NoobChain.validChainData(blockChain);
            } else {
                dataMap = blockChain.get(0).getData();

            }
        }
        String blockchainJsonFromFile = new GsonBuilder().setPrettyPrinting().create().toJson(blockChain);
        System.out.println("after.." + blockchainJsonFromFile);

        //model.put("message", "\n" + dataMap);  this will print all values together,we are now printing individually.so no need.
        System.out.println("Before extracting DATA is "+dataMap);//to check the format of data map
        a=0;
        b=0;
        c=0;
        if (dataMap.containsKey("A"))
        {
            a = dataMap.get("A");
            System.out.println("value for key \"A\" is:- " + a);
        }
        if (dataMap.containsKey("B"))
        {
            b = dataMap.get("B");
            System.out.println("value for key \"B\" is:- " + b);
        }
        if (dataMap.containsKey("C"))
        {
            c = dataMap.get("C");
            System.out.println("value for key \"C\" is:- " + c);
        }
        model.put("a", a);
        model.put("b", b);
        model.put("c", c);
        resultStatement="(A)Mike Shoe = "+a+",(B)Christeena Rod = "+b+",(C)Polk Johnson = "+c;//to make the statemnets into a result format



        return "adminhome"; //significance of this code is to return adminhome jsp page
    }




        @RequestMapping("/attackchk")
    public String attc(Map<String, Object> model) {
            ArrayList<Block> blockChain = NoobChain.getBlockChain();
            Map<String, Integer> dataMap = new HashMap<String, Integer>();
            if (!blockChain.isEmpty()) {

                if (!NoobChain.isChainValid(blockChain)) {    //if not valid to print the data.
                    model.put("msg", "Unathorized acess detected and vote data is attacked.");


                } else {
                    model.put("msg", "Vote Data is safe");


                }
            }



        return "attackchk";
    }

    @RequestMapping("/adminhome")
    public String adminhome(@RequestParam("username") String username, @RequestParam("pass") String pwd) {
        if (username.equals("admin") && pwd.equals("admin")) {


            return "adminchoose";
        } else
            return "adminlogin";

    }

    @RequestMapping("/pubvote")
    public String pubvot(Map<String, Object> model) {


        model.put("a", a);
        model.put("b", b);
        model.put("c", c);

        return "publishvote";

    }
    @RequestMapping("/citizenbroadcast")
    public String cibro(Map<String, Object> model) {

        smsService.sms(resultStatement);

        return "publishvote";

    }
    @RequestMapping("/broadcast")
    public String bro(Map<String, Object> model) {



        return "broadcast";

    }

    @RequestMapping("/knowcandidate")
    public String kno() {



        return "knowcandidate";

    }






}
