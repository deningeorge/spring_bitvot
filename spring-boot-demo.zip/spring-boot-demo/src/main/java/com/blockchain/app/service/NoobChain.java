package com.blockchain.app.service;

import com.google.gson.GsonBuilder;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class NoobChain {


    public static void setBlockChain(String args) {
        ArrayList<Block> blockChain = new ArrayList<Block>();

        //retrieving existing blockchain
        blockChain = getBlockChain();


        System.out.println("\nBlockchain is Valid: " + isChainValid(blockChain)); // testcase to check the blocks are valid
        Map<String, Integer> dataMap = new HashMap<String, Integer>(); //
        if (!blockChain.isEmpty()) {

            if (!isChainValid(blockChain)) {
                dataMap = validChainData(blockChain);
            } else {
                dataMap = blockChain.get(0).getData();    //this arraylist must need to be changed later to map
            }
        }



        if (!blockChain.isEmpty()) {
            Block blk = blockChain.get(0);

            dataMap = blk.getData();


        }
        Integer cnt = 0;
        if (!dataMap.isEmpty() && dataMap.containsKey(args)) {
            System.out.println("cnt..... "+cnt);//study more about collection interface ,,means suppose candidate a is present as key,we need to add value only
            cnt = dataMap.get(args);
        }
        cnt++;
        dataMap.put(args, cnt);
        System.out.println("datamap....."+dataMap);
        //adding first block
        Block genesisBlock = new Block(dataMap, "0");//giving first blocks previous hash as 0
        NoobChain.blockWriter("f0.txt", genesisBlock);
        System.out.println("Hash for genesis block  : " + genesisBlock.hash);
        for (int i = 1; i <= 9; i++) {

            Block newBlock = createBlock(dataMap, genesisBlock.hash, "f" + i + ".txt");

            System.out.println("Hash for block " + i + ":" + newBlock.hash);
            genesisBlock = newBlock;

        }



        blockChain = getBlockChain();
        System.out.println("\nBlockchain is Valid: " + isChainValid(blockChain));


        String blockchainJsonFromFile = new GsonBuilder().setPrettyPrinting().create().toJson(getBlockChain());
        System.out.println("after.." + blockchainJsonFromFile);

    }

    private static Block createBlock(Map<String, Integer> dataMap, String prevHash, String filename) {
        Block succesiveBlock = new Block(dataMap, prevHash);
        NoobChain.blockWriter(filename, succesiveBlock);

        return succesiveBlock;

    }

    private static void blockWriter(String fileName, Block block) {

        String blockTemp = new GsonBuilder().setPrettyPrinting().create().toJson(block);
        try {
            FileWriter fw = new FileWriter("/Users/denin/Documents/blockfile/" + fileName);  //method to make file
            fw.write(blockTemp);
            fw.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static Boolean isChainValid(ArrayList<Block> blockChain) {
        Block currentBlock;
        Block previousBlock;

        //loop through blockchain to check hashes:
        for (int i = 1; i < blockChain.size(); i++) {
            currentBlock = blockChain.get(i);
            previousBlock = blockChain.get(i - 1);
            //compare registered hash and calculated hash:
            if (!currentBlock.hash.equals(currentBlock.calculateHash())) {
                System.out.println("Current Hashes not equal.i.e may be corrupted Block is "+(i+1));
                return false;
            }
            //compare previous hash and registered previous hash
            if (!previousBlock.hash.equals(currentBlock.previousHash)) {
                System.out.println("Previous Hashes not equal");
                return false;
            }
        }
        return true;
    }

    public static Map<String, Integer> validChainData(ArrayList<Block> blockChain) {
        Block currentBlock;
        Block previousBlock;

        //loop through blockchain to check hashes:
        for (int i = 1; i < blockChain.size(); i++) {
            currentBlock = blockChain.get(i);
            previousBlock = blockChain.get(i - 1);
            //compare registered hash and calculated hash:
            if (currentBlock.hash.equals(currentBlock.calculateHash()) && previousBlock.hash.equals(currentBlock.previousHash)) {
                //System.out.println("Current Hashes not equal");
                return (Map<String, Integer>) currentBlock.getData();
                //return false
            }

        }
        return null;
    }

    public static ArrayList<Block> getBlockChain() {
        ArrayList<Block> blockChain = new ArrayList<Block>();
        try {
            ArrayList<Path> fileList = (ArrayList<Path>) Files.walk(Paths.get("/Users/denin/Documents/blockfile")).map(Path::getFileName)
                    .filter(s -> s.toString().endsWith(".txt")).sorted().collect(Collectors.toList());
            fileList.forEach(s -> {
                try {
                    String content = new String(Files.readAllBytes(Paths.get("/Users/denin/Documents/blockfile/" + s.toString())));
                    Block block = new GsonBuilder().setPrettyPrinting().create().fromJson(content, Block.class); //

                    blockChain.add(block);
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            });
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return blockChain;
    }

}


