package com.blockchain.app.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.net.URL;
import java.util.*;

public class SMSAPIJAVA {


    static char[] OTP(int len) {
        System.out.println("Generating OTP using random() : ");


        // Using numeric values
        String numbers = "0123456789";

        // Using random method
        Random rndm_method = new Random();

        char[] otp = new char[len];

        for (int i = 0; i < len; i++) {
            // Use of charAt() method : to get character value
            // Use of nextInt() as it is scanning the value as int
            otp[i] =
                    numbers.charAt(rndm_method.nextInt(numbers.length()));
        }
        return otp;
    }

    public static int otpCall() {
        // TODO code application logic here
        int length = 4;
        char[] o = new char[4];
        o = OTP(length);
        System.out.println("otp before converting"+o);
        int num = Integer.parseInt(new String(o));
        System.out.print("otp after converting"+num);
        System.out.println();



        try {
            URL url = new URL("http://control.msg91.com/api/sendotp.php?authkey=261653AbnFlmxjEUmo5c5adcfa&message=OTP is "+num + "&sender=BITVOT&mobile=919846135851&otp="+num);
            URLConnection urlcon = url.openConnection();
            InputStream stream = urlcon.getInputStream();
            int i;
            String response = "";
            while ((i = stream.read()) != -1) {
                response += (char) i;
            }
            if (response.contains("success")) {
                System.out.println("Successfully send SMS");
                //your code when message send success
            } else {
                System.out.println(response);
                //your code when message not send
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return num;




    }
}







