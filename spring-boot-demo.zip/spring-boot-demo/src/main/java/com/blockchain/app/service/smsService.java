package com.blockchain.app.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public class smsService {




    public static void sms(String resultStatement) {
        // TODO code application logic here



        try {
            URL url = new URL("http://api.msg91.com/api/sendhttp.php?route=4&sender=BITVOT&mobiles=919846135851&authkey=261653AbnFlmxjEUmo5c5adcfa&message=Election results declared.Results are "+resultStatement+"&country=91");
            URLConnection urlcon = url.openConnection();
            InputStream stream = urlcon.getInputStream();
            int i;
            String response = "";
            while ((i = stream.read()) != -1) {
                response += (char) i;
            }
            if (response.contains("success")) {
                System.out.println("Successfully send SMS");
                //your code when message send success
            } else {
                System.out.println(response);
                //your code when message not send
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }





    }
}











